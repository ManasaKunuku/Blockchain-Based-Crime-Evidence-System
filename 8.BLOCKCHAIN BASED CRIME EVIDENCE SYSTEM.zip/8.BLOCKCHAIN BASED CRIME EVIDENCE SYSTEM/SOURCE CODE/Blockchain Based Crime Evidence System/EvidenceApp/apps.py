from django.apps import AppConfig


class EvidenceappConfig(AppConfig):
    name = 'EvidenceApp'
